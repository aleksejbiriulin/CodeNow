/*
 *  В этот файл Вы можете вставить определения своих функций
 */
#include <iostream>

#include "tree.h"

// первое значение пары это сумма второй это максимальное значение
std::pair<int, int> Set_Balance(TreeNode* pos) {
  if (pos == nullptr) {
    return {0, 0};
  }
  std::pair<int, int> result_left = Set_Balance(pos->left);
  std::pair<int, int> result_right = Set_Balance(pos->right);
  std::pair<int, int> result =
      std::make_pair(result_left.first + result_right.first,
                     std::max(result_left.second, result_right.second));
  pos->balance = result.first - result.second;
  return result;
}

void refrush_X(TreeNode* pos, int X) {
  if (pos == nullptr) {
    return;
  }
  if (pos->value == X) {
    int left_sum = free_and_sum(pos->left);
    int right_sum = free_and_sum(pos->right);
    pos->left = new TreeNode();
    pos->right = new TreeNode();
    pos->left->value = left_sum;
    pos->right->value = right_sum;
    return ;
  }
  refrush_X(pos->left, X);
  refrush_X(pos->right, X)
}
int free_and_sum(TreeNode* pos) {
  if (pos == nullptr) {
    return 0;
  }
  int s = pos->value;
  s += free_and_sum(pos->left);
  s += free_and_sum(pos->right);
  delete[] pos;
  return s;
}